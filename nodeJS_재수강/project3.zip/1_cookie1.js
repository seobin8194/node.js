/*
    cookie-parser
    쿠키를 쉽게 설정하고 사용할 수 있게 도와주는 모듈
    익스프레스 객체에 미들웨어로 등록

    cookieParser(): 일반 쿠키를 사용
    cookieParser('암화화하기 위한 문자'): 암화화된 쿠키를 사용

    쿠키생성
    서버가 클라이언트에게 쿠키를 심는 것
    res.cookie('키', '값', {
        쿠키생성 옵션
    })
    쿠키생성 옵션
    maxAge: 만료시간을 밀리초 단위로 설정
    expires: 만료시간을 GMT시간으로 설정
    path: cookie의 경로를 설정. 기본설정은 "/"

    쿠키조회
    req.cookies.cookie: 일반 쿠키
    req.signedCookies.cookie: 암호화된 쿠키를

    쿠키삭제
    res.clearCookie('키', {path: '경로'});
*/


const express = require('express');
const cookieParser = require('cookie-parser');

const app = express();
const port = 3000;

//cookirParsr 미들웨어 등록
app.use(cookieParser());

//쿠키생성
app.get('/setCookie', (req, res) => {
    console.log('setCookie 호출');
    res.cookie('member', {
        id: 'banana',
        name: '반하나',
        gender: '여자'
    }, {
        maxAge: 1000 * 60 * 3
    });
    res.redirect('/showCookie');
});

//쿠키조회
app.get('/showCookie', (req, res) => {
    console.log('showCookie 호출');
    res.send(req.cookies);
    res.end();
})

app.listen(port, () => {
    console.log('서버 실행 중');
})