/*  
    express-session모듈
    세션을 관리하기 위한 익스프레스 미들웨어 모둘
    app.use(session({세션모듈의 옵션}));

    세션 모듈의 옵션
    secret: 쿠키를 임의로 변조하는 것을 방지하기 위한 값. 이 값을 통해 세션을 암호화하여 저장
    resave: 세션을 얼마나 저장할지 지정하는 값. 이 값을 false로 하는 것을 권장
    saveUninitialized: 세션이 저장되기 전에 saveUninitialized상태로 미리 만들어서 저장

    세션 초기 설정
    const 세션객체 = req.session;
    세션객체명.변수 = 값;

    세션변수 사용하는 방법
    세션객체명.변수;

    세션삭제
    req.session.destroy(() => {
        세션 삭제시 처리할 문장
    });
*/


const express = require('express');
const expressSession = require('express-session');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({extended:false}));
//expressSession 미들웨어 등록
app.use(expressSession({
    secret: '!@#$%^&*()',
    resave: false,
    saveUninitialized: true
}))

app.get('/login', (req, res) => {
    fs.readFile('login.html', 'utf8', (err, data) => {
        if(err){
            console.log(err);
        }else{
            res.writeHead(200, {'content-type':'text/html'});
            res.end(data);
        }
    })
})

app.post('/login', (req, res) => {
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    console.log(`userid: ${userid}, userpw: ${userpw}`);

    if(userid == 'admin' && userpw == '1234'){
        //세션생성
        req.session.member = {
            id: userid,
            userpw: userpw,
            isauth: true
        }
        res.redirect('/main');
    }else{
        res.redirect('/login');
    }
});

app.get('/main', (req, res) => {
    console.log(req.session.member);
    //세션조회
    if(req.session.member){
        fs.readFile('main.html', 'utf8', (err, data) => {
            res.writeHead(200, {'content-type':'text/html'});
            res.end(data);
        })
    }else{
        res.redirect('/login');
    }
});

app.get('/logout', (req, res) => {
    //세션삭제
    req.session.destroy(() => {
        console.log('세션이 삭제되었어요');
    })
    res.redirect('/login');
});

app.listen(port, () => {
    console.log('서버 실행 중');
});