/*
    mongoose모듈
    MongoDB의 ODM(Object Data Mapping)
    * ODM
      데이터베이스와 객체지향 프로그래밍 언어 사이 호환되지 않는 데이터를 변환하는 프로그래밍 기법
    하나의 컬렉션 안에 똑같은 속성을 가진 문서객체를 반복적으로 넣어두면 데이터를 조회할때도 어떤 속성들이 있는지 미리 알고 있는 상태에서 조회할 수 있음 -> 스키마 생성 가능

    mongoDB vs mongoose
    mongoDB: 자바에서 jdbc드라이버 -> 속도빠름
    mongoose: 자바에서 mybatis나 hibernate -> 확장성

    db연결
    mongoose객체.connect(uri, 옵션, 콜백)

    스키마
    데이터 유효성 검증을 위해 스키마 사용가능
    데이터 타입 및 규약 등 설정가능
    * 스키마에 사용되는 데이터 타입
      String, Number, Date, Boolean, Array

    스키마 생성
    mongoose.Schema({속성:데이터 타입 및 규약, ..})

    모델
    데이터베이스에서 데이터를 읽고 생성하고 수정하는 인터페이스를 정의해줌

    모델 정의
    mongoose.model(컬렉션명, 스키마명);
    * 컬렉션이름을 지정하지 않으면 1번째 매개변수에 s를 붙여 복수형으로 사용

    document객체 생성
    new 모델명(정의한 스키마대로 만든 document객체)
    document객체.save((err, result) => {})

    document 객체 조회
    모델명.find(객체, (err, result) => {})

    스키마에 가상함수 만들기
    스키마명.static('함수명', 실행함수)

    가상함수 실행
    모델명.함수명()
*/


const express = require('express');
const bodyParser = require('body-parser');
const logger = require('morgan');
const mongoose = require('mongoose');

const app = express();
const port = 3000;
const router = express.Router();

app.use(bodyParser.urlencoded({"extended":false}));
app.use(logger('dev'));

let database;
let UserSchema;
let UserModel;

//http://127.0.0.1:3000/regist
router.route('/regist').post((req, res) => {
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    const name = req.body.name;
    const gender = req.body.gender;

    console.log(`userid:${userid}, userpw:${userpw}, name:${name}, gender:${gender}`);

    if(database){
        joinUser(userid, userpw, name, gender, (err, result) => {
            if(err){
                res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                res.write('<h2>회원가입 실패(서버 에러)</h2>');
                res.end();
            }else{
                if(result){
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원가입 성공</h2>');
                    res.end();
                }else{
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원가입 실패</h2>');
                    res.end();
                }
            }
        })
    }else{
        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.end();
    }
});

//http://127.0.0.1:3000/login
router.route('/login').post((req, res) => {
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    console.log(`userid:${userid}, userpw:${userpw}`);

    if(database){
        loginUser(userid, userpw, (err, result) => {
            if(err){
                res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                res.write('<h2>로그인 실패(서버 오류)</h2>');
                res.end();
            }else{
                if(result){
                    console.dir(result);
                    const name = result[0].name;
                    const gender = result[0].gender;

                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>로그인 성공</h2>');
                    res.write(`<p>아이디 ${userid}</p>`);
                    res.write(`<p>이름 ${name}</p>`);
                    res.write(`<p>성별 ${gender}</p>`);
                    res.end();
                }else{
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>로그인 실패</h2>');
                    res.end();
                }
            }
        })
    }else{
        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.end();
    }
})

//http://127.0.0.1:3000/list
router.route('/list').get((req, res) => {
    if(database){
        //스키마에 정의된 가상함수 실행
        UserModel.findAll((err, result) => {
            if(err){
                console.log('리스트조회 실패');
                return
            }else{
                if(result){
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원 리스트</h2>');
                    res.write('<div><ul>');
                    for(let i=0; i<result.length; i++){
                        const userid = result[i].userid;
                        const name = result[i].name;
                        const gender = result[i].gender;
                        res.write(`<li>${i}: ${userid}/${name}/${gender}</li>`)
                    }
                    res.write('</ul></div>');
                    res.end();
                }else{
                    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원정보가 없습니다</h2>');
                    res.end();
                }
            }
        })
    }else{
        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.end();
    }
})

const joinUser = function(userid, userpw, name, gender, callback){
    //document 객체 생성
    const users = new UserModel({userid:userid, userpw:userpw, name:name, gender:gender});
    users.save((err, result) => {
        if(err){
            console.log(err);
            callback(err, null)
            return;
        }else{
            callback(null, result);
        }
    })
}

const loginUser = function(userid, userpw, callback){
    //document 객체 조회
    UserModel.find({userid:userid, userpw:userpw}, (err, result) => {
        if(err){
            console.log(err);
            callback(err, null)
            return;
        }else{
            if(result.length > 0){
                console.log('일치하는 사용자를 찾음');
                callback(null, result);
            }else{
                console.log('일치하는 사용자가 없음');
                callback(null, null);
            }
        }
    })
}

function connectDB(){
    const uri = "mongodb://127.0.0.1:27017/frontend";
    //global.Promise: 전역에서 mongoose를 비동기식으로 사용
    mongoose.Promise = global.Promise;
    //접속
    mongoose.connect(uri, {useNewUrlParser: true, useUnifiedTopology: true});
    //mongoDB 연결객체 가져오기
    database = mongoose.connection;

    database.on('error', console.error.bind(console, "mongoose 연결 실패"));
    database.on('open', () => {
        console.log('데이터베이스 연결 성공');

        //스키마 생성
        UserSchema = mongoose.Schema({
            userid:String,
            userpw:String,
            name:String,
            gender:String
        });
        console.log('UserSchema 생성 완료');

        //스키마안에 가상함수 만들기
        //전체 리스트 조회하는 함수
        UserSchema.static('findAll', function(callback){
            return this.find({}, callback);
        })

        //모델 정의
        UserModel = mongoose.model('user', UserSchema);
        console.log('UserModel 생성 완료');
    });
}

app.use('/', router);

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중`);
    connectDB();
});