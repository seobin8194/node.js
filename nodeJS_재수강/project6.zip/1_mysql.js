/*
    mysql모듈
    mysql과 연결하기 위한 모듈
    connection pool을 사용하여 연결
    * connection pool
      미리 connection객체를 확보해놓고 확보한 만큼은 바로 사용할 수 있음
      사용자가 접속할때마다 connection객체를 생성하여 너무 많은 연결객체를 만들면 메모리가 낭비될 수 있다
      이때 connection pool에 연결객체를 미리 만들어 사용하고 연결객체가 부족하면 사용자는 대기 후 해제되는 객체를 재활용한다
      따라서 connection pool을 이용하면 데이터베이스 연결객체가 너무 많이 만들어지는 것을 막을 수 있고 기존의 연결객체를 재활용할 수 있다
    

     mysql 연결 설정
     connectionLimit: connection pool에서 만들 수 있는 최대 연결 개수 설정 
                      최대 연결 개수가 너무 많으면 메모리에 사용하지 않는 객체가 존재하여 메모리가 낭비될 수 있음
                      동시접속 시 연결 가능 개수
     host: 연결할 호스트 이름 설정
     port: 데이터베이스가 사용하는 포트번호 설정
     user: 데이터베이스 사용자 아이디 설정
     password: 데이터베이스 사용자 비밀번호 설정
     database: 데이터베이스 이름 설정


     mysql.createPool(config파일): 새로운 pool생성
     pool객체.getConnection(): pool에서 connection가져오기
     conn객체.Release(): connection반납
*/


const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const logger = require('morgan');
const config = require('./config.json')

const app = express();
const port = 3000;
const router = express.Router();

app.use(bodyParser.urlencoded({"extended":false}));
app.use(logger('dev'));

/* pool 생성
    mysql.createPool({
        "connectionLimit":30,
        "host":"127.0.0.1",
        "port":"3306",
        "user":"root",
        "password":"1234",
        "database":"frontenddb"
    })
*/
const pool = mysql.createPool(config);


//http://127.0.0.1:3000/regist
router.route('/regist').post((req, res) => {
    const mem_userid = req.body.mem_userid;
    const mem_userpw = req.body.mem_userpw;
    const mem_name = req.body.mem_name;
    const mem_hp = req.body.mem_hp;
    const mem_email = req.body.mem_email;
    const mem_hobby = req.body.mem_hobby;
    const mem_ssn1 = req.body.mem_ssn1;
    const mem_ssn2 = req.body.mem_ssn2;
    const mem_zipcode = req.body.mem_zipcode;
    const mem_address1 = req.body.mem_address1;
    const mem_address2 = req.body.mem_address2;
    const mem_address3 = req.body.mem_address3;

    console.log(`mem_userid:${mem_userid},mem_userpw:${mem_userpw},mem_name:${mem_name},mem_hp:${mem_hp},mem_email:${mem_email},mem_hobby:${mem_hobby},mem_ssn1:${mem_ssn1},mem_ssn2:${mem_ssn2},mem_zipcode:${mem_zipcode},mem_address1:${mem_address1},mem_address2:${mem_address2},mem_address3:${mem_address3}`);

    if(pool){
        joinMember(mem_userid, mem_userpw, mem_name, mem_hp, mem_email, mem_hobby, mem_ssn1, mem_ssn2, mem_zipcode, mem_address1, mem_address2, mem_address3, (err, result) => {
            if(err){
                res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                res.write('<h2>회원가입 실패</h2>');
                res.end();
            }else{
                res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                res.write('<h2>회원가입 성공</h2>');
                res.end();
            }
        });
    }else{
        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.end();
    }
});

//http://127.0.0.1:3000/login
router.route('/login').post((req, res) => {
    const mem_userid = req.body.mem_userid;
    const mem_userpw = req.body.mem_userpw;

    console.log(`mem_userid: ${mem_userid}, mem_userpw: ${mem_userpw}`);

    if(pool){
        loginMember(mem_userid, mem_userpw, (err, result) => {
            if(err){
                res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                res.write('<h2>로그인 실패</h2>');
                res.end();
            }else{
                console.dir(result);
                const idx = result[0].mem_idx;
                const userid = result[0].mem_userid;
                const name = result[0].mem_name;
                const hp = result[0].mem_hp;

                res.writeHead('200', {'content-type':'text/html;charset=utf8'});
                res.write('<h2>로그인 성공</h2>');
                res.write(`<p>번호 ${idx}</p>`)
                res.write(`<p>아이디 ${userid}</p>`)
                res.write(`<p>이름 ${name}</p>`)
                res.write(`<p>핸드폰 ${hp}</p>`)
                res.end();
            }
        })
    }else{
        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.end();
    }
});

const joinMember = function(mem_userid, mem_userpw, mem_name, mem_hp, mem_email, mem_hobby, mem_ssn1, mem_ssn2, mem_zipcode, mem_address1, mem_address2, mem_address3, callback){
    //pool.getConnection(): pool에서 connection가져오기
    pool.getConnection((err, conn) => {
        if(err){
            console.log(err);
            return;
        }else{
            console.log('데이터베이스 연결 성공');
            //query
            const sql = conn.query('insert into tb_member(mem_userid, mem_userpw, mem_name, mem_hp, mem_email, mem_hobby, mem_ssn1, mem_ssn2, mem_zipcode, mem_address1, mem_address2, mem_address3) values (?,?,?,?,?,?,?,?,?,?,?,?)', [mem_userid, mem_userpw, mem_name, mem_hp, mem_email, mem_hobby, mem_ssn1, mem_ssn2, mem_zipcode, mem_address1, mem_address2, mem_address3], (err, result) => {
                //conn.release(): connection반납
                conn.release();
                if(err){
                    callback(err, null);
                    return;
                }else{
                    console.log('가입완료');
                    callback(null, result);
                }
            });
        }
    });
}

const loginMember = function(mem_userid, mem_userpw, callback){
    pool.getConnection((err, conn) => {
        if(err){
            console.log(err);
            return
        }else{
            const sql = conn.query('select mem_idx, mem_userid, mem_name, mem_hp from tb_member where mem_userid=? and mem_userpw=?', [mem_userid, mem_userpw], (err, result) => {
                conn.release();
                if(err){
                    callback(err, null);
                    return;
                }else{
                    if(result.length > 0){
                        console.log('일치하는 사용자를 찾음');
                        callback(null, result);
                    }else{
                        console.log('일치하는 사용자가 없음');
                        callback(null, null);
                    }
                    return;
                }
            })
        }
    })
}

app.use('/', router);

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중`);
});