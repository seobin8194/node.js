/*
    MongoDB모듈의 MongoClient객체
    몽고디비와 연결할 수 있는 객체

    MongoClient.connect(databaseURL, (err, db) => {}): 몽고디비와 연결. 연결 성공시 db객체 반환

    db.db(데이터베이스 명): 해당 데이터베이스와 연결
*/


const express = require('express');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;

const app = express();
const router = express.Router();
const port = 3000;

let database; //몽고디비 연결 객체

app.use(bodyParser.urlencoded({extends:false}));

//회원가입
//http://localhost:3000/member/regist (post)
router.route('/member/regist').post((req, res) => {
    console.log('/member/regist 호출');
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    const name = req.body.name;
    const gender = req.body.gender;

    //console.log(`userid:${userid} userpw:${userpw} name:${name} gender:${gender}`);

    //익명함수: 함수 내에서 callback함수에서 err 혹은 result객체와 함께 돌아와 실행되는 함수
    if(database){
        joinMember(database, userid, userpw, name, gender, (err, result) => {
            if(err){
                res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                res.write('<h2>회원가입 실패</h2>');
                res.write('<p>오류가 발생했습니다</p>');
                res.end();
            }else{
                if(result.insertedCount > 0){
                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원가입 성공</h2>');
                    res.write('<p>가입이 성공적으로 완료되었습니다</p>');
                    res.end();
                }else{
                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원가입 실패</h2>');
                    res.write('<p>가입이 성공적으로 완료되지 못했습니다</p>');
                    res.end();
                }
            }
        });
    }else{
        res.writeHead(200, {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.write('<p>mongoDB에 연결하지 못했습니다</p>');
        res.end();
    }
});

//로그인
//http://localhost:3000/member/login (post)
router.route('/member/login').post((req, res) => {
    console.log('/member/login 호출');
    const userid = req.body.userid;
    const userpw = req.body.userpw;

    console.log(`userid:${userid}, userpw:${userpw}`);

    if(database){
        loginMember(database, userid, userpw, (err, result) => {
            if(err){
                res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                res.write('<h2>로그인 실패</h2>');
                res.write('<p>오류가 발생했습니다</p>');
                res.end();
            }else{
                if(result){
                    //select결과는 배열로 넘어 온다
                    const result_userid = result[0].userid;
                    const result_userpw = result[0].userpw;
                    const result_name = result[0].name;
                    const result_gender = result[0].gender;

                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>로그인 성공</h2>');
                    res.write(`<p>아이디 : ${result_userid}</p>`);
                    res.write(`<p>비밀번호 : ${result_userpw}</p>`);
                    res.write(`<p>이름 : ${result_name}</p>`);
                    res.write(`<p>성별 : ${result_gender}</p>`);
                    res.end();
                }else{
                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>로그인 실패</h2>');
                    res.write('<p>아이디 또는 비밀번호를 확인하세요</p>');
                    res.end();
                }
            }
        });
    }else{
        res.writeHead(200, {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.write('<p>mongoDB에 연결하지 못했습니다</p>');
        res.end();
    }
});

//정보수정
//http://localhost:3000/member/edit (put)
router.route('/member/edit').put((req, res) => {
    console.log('/member/edit');

    const userid = req.body.userid;
    const userpw = req.body.userpw;
    const name = req.body.name;
    const gender = req.body.gender;

    console.log(`userid:${userid} userpw:${userpw} name:${name} gender:${gender}`);

    if(database){
        editMember(database, userid, userpw, name, gender, (err, result) => {
            if(err){
                res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                res.write('<h2>회원정보 수정 실패</h2>');
                res.write('<p>오류가 발생했습니다</p>');
                res.end();
            }else{
                if(result.modifiedCount > 0){
                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원정보 수정 성공</h2>');
                    res.write('<p>정보수정 성공했습니다</p>');
                    res.end();

                }else{
                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원정보 수정 실패</h2>');
                    res.write('<p>정보수정 실패했습니다</p>');
                    res.end();
                }
            }
        })
    }else{
        res.writeHead(200, {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.write('<p>mongoDB에 연결하지 못했습니다</p>');
        res.end();
    }
});

//회원 삭제
//http://localhost:3000/member/delete (delete)
router.route('/member/delete').delete((req, res) => {
    console.log('/member/delete 호출');
    const userid = req.body.userid;

    console.log(`userid:${userid}`);

    if(database){
        deleteMember(database, userid, (err, result) => {
            if(err){
                res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                res.write('<h2>회원 삭제 실패</h2>');
                res.write('<p>오류가 발생했습니다</p>');
                res.end();
            }else{
                if(result.deletedCount > 0){
                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원 삭제 성공</h2>');
                    res.write('<p>회원삭제 성공했습니다</p>');
                    res.end();
                }else{
                    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
                    res.write('<h2>회원 삭제 실패</h2>');
                    res.write('<p>회원삭제 실패했습니다</p>');
                    res.end();
                }
            }
        })
    }else{
        res.writeHead(200, {'content-type':'text/html;charset=utf8'});
        res.write('<h2>데이터베이스 연결 실패</h2>');
        res.write('<p>mongoDB에 연결하지 못했습니다</p>');
        res.end();
    }
});


const joinMember = function(database, userid, userpw, name, gender, callback){
    console.log('joinMember 호출');

    //collection(컬렉션명): 컬렉션 가져오기
    const members = database.collection('member');

    //컬렉션.insertMany([객체, 객체, ..]): 여러 객체 대입
    members.insertMany([{'userid':userid, 'userpw':userpw, 'name':name, 'gender':gender}], (err, result) => {
        if(err){
            console.log(err);
            //호출한 곳으로 err객체 반환
            callback(err, null);
            return;
        }else{
            //result.insertedCount: 저장된 행의 개수
            if(result.insertedCount > 0){
                console.log(`사용자 document ${result.insertedCount}명이 추가됨`);
            }else{
                console.log(`사용자 document가 추가되지 않았습니다`);
            }
            //호출한 곳으로 result객체 반환
            callback(null, result);
        }
    });
}

const loginMember = function(database, userid, userpw, callback){
    console.log('loginMember 호출');

    const members = database.collection('member');

    //find(객체): 해당 객체와 일치하는 객체 가져옴. 여러 객체를 가져 올 수 있으므로 toArray()
    members.find({'userid':userid, 'userpw':userpw}).toArray((err, result) => {
        if(err){
            console.log(err);
            callback(err, null);
            return;
        }else{
            if(result.length > 0){
                console.log('사용자를 찾았습니다');
                callback(null, result);
            }else{
                console.log('일치하는 사용자가 없습니다');
                callback(null, null);
            }
        }
    });
}

const editMember = function(database, userid, userpw, name, gender, callback){
    console.log('editMember 호출');

    const members = database.collection('member');

    //updateOne(기존 객체, 수정할 객체): 하나의 객체 수정
    members.updateOne({'userid':userid}, {$set:{'userid':userid, 'userpw':userpw, 'gender':gender, 'name':name}}, (err, result) => {
        if(err){
            console.log(err);
            callback(err, null);
            return;
        }else{
            //result.modifiedCount: 수정된 행의 개수
            if(result.modifiedCount > 0){
                console.log(`사용자 document ${result.modifiedCount}명이 수정되었습니다`);
            }else{
                console.log('수정된 document가 없습니다');
            }
            callback(null, result);
        }
    });
}

const deleteMember = function(database, userid, callback){
    console.log('deleteMember 호출');
    const members = database.collection('member');

    //deleteOne(): 객체 하나 삭제
    members.deleteOne({userid:userid}, (err, result) => {
        if(err){
            console.log(err);
            callback(err, null);
            return;
        }else{
            if(result.deletedCount > 0){
                console.log(`사용자 document ${result.deletedCount}명이 삭제되었습니다`);
            }else{
                console.log('삭제된 사용자가 없습니다');
            }
            callback(null, result);
        }
    });
}


//몽고디비와 연결하는 함수
function connectionDB(){
    const databaseURL = "mongodb://localhost:27017";
    MongoClient.connect(databaseURL, (err, db) => {
        if(err){
            console.log(err);
        }else{
            const temp = db.db('frontend');
            database = temp;
            console.log('mongodb 데이터베이스 연결 성공');
        }
    });
}


app.use("/", router);

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중,,`);
    connectionDB();
});