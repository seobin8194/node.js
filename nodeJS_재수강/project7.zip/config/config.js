module.exports = {
    server_port: 3000,
    db_url: 'mongodb://127.0.0.1:27017/frontend',
    db_schemas: [{file:'./member_schema', collection:'member2', schemaName:'MemberSchema', modelName:'MemberModel'}],
    facebook: {
        clientID: '225217372428698',
        clientSecret: '131a237875f416bd4a3ba0eea45ce9f2',
        callbackURL: 'http://127.0.0.1:3000/auth/facebook/callback'
    }
}