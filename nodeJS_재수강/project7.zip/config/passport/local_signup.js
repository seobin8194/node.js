const LocalStrategy = require('passport-local').Strategy;

module.exports = new Strategy({
    usernameField: 'userid',
    passwordField: 'userpw',
    passReqToCallback: true
}, (req, userid, userpw, done) => {
    const name = req.body.name;
    const age = req.body.age;
    console.log(`passport의 local-signup 호출: userid:${userid}, userpw:${userpw}, name:${name}, age:${age}`);

    process.nextTick(() => {
        let database = req.app.get('database');
        database.MemberModel.findOne({userid:userid}, (err, ueser) => {
            if(err) {return done(err)}


        })
    });
})