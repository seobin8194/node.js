/*
    메일 보내기
    nodemailer 모듈
    gmail 서버를 이용하여 메일을 보냄

    nodemailer 설정
    createTransport({
        service: 'Gmail',
        auth: {
            user: 'gmail 계정',
            pass: '비밀번호'
        },
        host: 'smtp.mail.com',
        port: '465'
    });

    mail발송
    const 객체명 = {
        from: '이름<메일주소>',
        to: 이름<메일주소>',
        subject: '제목',
        text: '내용'
        (html: 'html코드')
    }

    보안수준이 낮은 앱 액세스
    https://myaccount.google.com/lesssecureapps
    계정 액세스 사용을 허용
    https://accounts.google.com/DisplayUnlockCaptcha
*/


const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'wjdtjqls8194@gmail.com',
        pass: 'hoho1010!@'
    },
    host: 'smtp.mail.com',
    port: '465'
});

const mailOption = {
    from: '정서빈<wjdtjqls8194@gmail.com>',
    to: '정서빈<wjdtjqls1010@naver.com>',
    subject: 'node.js로 보내는 메일',
    html: "<h2>안녕하세요 node.js로 보내는 메일입니다</h2> <p style='font-size: 15px; color: deeppink'>정말 잘 가나요</p>"
};

transporter.sendMail(mailOption, (err, info) => {
    if(err){
        console.log(err);
    }else{
        transporter.close();
    }
});