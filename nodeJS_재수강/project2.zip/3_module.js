/*
    사용자 정의 모듈
    사용자가 직접 만들어 코드를 관리할 수 있도록 작성한 모듈

    1. 
    module.exports = () => {
        모듈코드
    }
    const 객체명 = require('파일명');

    2. 
    모듈 코드
    module.export = 변수
    const 객체명 = require('변수명');
*/


const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

//view엔진으로 ejs를 express에 등록
//view엔진을 등록하여 사용하는 경우 view파일들을 views폴더에 만들어야 한다
app.engine('html', require('ejs').renderFile);
app.use(bodyParser.urlencoded({extended:false}));

//파일명으로 사용자 정의 모듈 가져와 실행
const module1 = require('./router/module1')(app, fs);

app.listen(port, () => {
    console.log('서버 실행 중');
});