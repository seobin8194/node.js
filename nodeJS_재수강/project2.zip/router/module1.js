/*
    사용자 정의 모듈
     module.exports = () => {
        모듈코드
    }

    json(Javascript Object Notation)
    데이터를 교환하고 저장하기 위해 만들어진 텍스트 기반의 데이터 교환 표준언어
    node.js나 php로 데베에 저장된 데이터를 기반으로 json페이지를 만들고 다른 사이트나 앱 등이 json 페이지를 호출하여 텍스트를 긁어와 parsing하여 데이터를 시용
    프론트는 백엔드에게 데이터를 요청하고 백엔드에서 데이터를 전달하고 프론트에서 전달받은 데이터를 이용하여 화면을 재구성

    {
        "userid":"apple",
        "userpw":"1111",
        "name":"김사과",
        "gender":"여자",
        "age":20,
        "hobby":[
            "드라이브",
            "쇼핑",
            "영화감상"
        ]
    }
    예를들어 127.0.0.1:3000/userinfo/1 호출이 들어오면 db에서 해당 사용자를 가져와 뿌린 페이지를 보여준다

    {
        "userlist":[
            {"userid":"apple", "name":"김사과","gender":"여자"},
            {"userid":"banana", "name":"반하나","gender":"여자"},
            {"userid":"orange", "name":"오렌지","gender":"남자"}
        ]
    }
    예를들어 127.0.0.1:3000/userlist 호출이 들어오면 db에서 모든 사용자 정보를 가져와 뿌린 페이지를 보여준다

    json문법 검증 사이트
    https://jsonlint.com/
*/


module.exports = (app, fs) => {
    //http://localhost:3000
    app.get('/', (req, res) => {
        res.render('index.ejs', {
            length: 10
        });
    });

    //http://localhost:3000/about
    app.get('/about', (req, res) => {
        res.render('about.html');
    });  


    //http://localhost:3000/list
    //json파일 전체 데이터 가져오기
    app.get('/list', (req, res) => {
        //__dirname: 현재 디렉토리
        fs.readFile(__dirname + "/../data/member.json", "utf-8", (err, data) => {
            if(err){
                console.log(err);
            }else{
                console.log(data);
                res.writeHead(200, {"content-type":"text/json;charset=utf-8"});
                res.end(data);
            }
        });
    });

    //http://localhost:3000/getMember/banana
    //특정 사용자 정보 가져오기
    //get('/getMember/:변수명'): url을 동적으로 처리 가능
    app.get('/getMember/:userid', (req, res) => {
        fs.readFile(__dirname + "/../data/member.json", "utf8", (err, data) => {
            if(err){
                console.log(err);
            }else{
                //JSON.parse(문자열)): JSON포멧으로 되어 있는 문자열을 JSON객체로 변환
                const member = JSON.parse(data);
                //res.json(): 화면에 json형태로 출력
                //req.params.변수명: url에 포함된 데이터 가져오기
                res.json(member[req.params.userid])
            }
        })
    })

    //http://localhost:3000/joinMember/avocado
    //사용자 추가하기
    app.post('/joinMember/:userid', (req, res) => {
        const result = {};
        const userid = req.params.userid;

        //post데이터가 넘어 오지 않았을때
        if(!req.body["password"] || !req.body["name"]){
            //프론트에서 url형식으로 백엔드에게 요청하고 백엔드가 처리 후 code형식으로 반환
            //프로트는 code에 따라 화면처리하는 방식
            result["code"] = 100; //100:실패
            result["msg"] = "매개변수가 제대로 전달되지 않음";
            res.json(result);
            return false;
        }

        fs.readFile(__dirname+"/../data/member.json", "utf8", (err, data) => {
            if(err){
                console.log(err);
            }else{
                const member = JSON.parse(data);

                if(member[userid]){
                    result["code"] = 101; //101:중복된 아이디
                    result["msg"] = "중복된 아이디";
                    res.json(result);
                    return false;
                }

                console.log(req.body);
                member[userid] = req.body;

                //JSON.stringify(JSON 객체): JSON객체를 JSON포멧의 문자열로 변환
                fs.writeFile(__dirname+"/../data/member.json", JSON.stringify(member, null, '\t'), 'utf8', (err, data) => {
                    if(err){
                        console.log(err);
                    }else{
                        result["code"] = 200; //200:성공
                        result["msg"] = "성공";
                        res.json(result);
                    }
                });
            }
        });
    });

    //http://localhost:3000/updateMember/avocado
    //사용자 수정하기
    app.put('/updateMember/:userid', (req, res) => {
        const result = {};
        const userid = req.params.userid;

        if(!req.body['password'] || !req.body['name']){
            result['code'] = 100
            result['msg'] = "매개변수가 전달되지 않음";
            res.json(result);
            return false;
        }

        fs.readFile(__dirname+"/../data/member.json", "utf8", (err, data) => {
            if(err){
                console.log(err);
            }else{
                const member = JSON.parse(data);

                member[userid] = req.body;
                
                fs.writeFile(__dirname+"/../data/member.json", JSON.stringify(member, null, '\t'), 'utf8', (err, data) => {
                    if(err){
                        console.log(err);
                    }else{
                        result['code'] = 200;
                        result['msg'] = "성공";
                        res.json(result);
                    }
                });
            }
        });
    });

     //http://localhost:3000/deleteMember/avocado
    //사용자 삭제하기
    app.delete('/deleteMember/:userid', (req, res) => {
        const result = {};
        fs.readFile(__dirname+"/../data/member.json", "utf8", (err, data) => {
            if(err){
                console.log(err);
            }else{
                const member = JSON.parse(data);
                if(!member[req.params.userid]){
                    result['code'] = 102; //102:멤버 없음
                    result['msg'] = "사용자를 찾을 수 없음";
                    return false;
                }

                //delete: key-value 한쌍 삭제
                delete member[req.params.userid];

                fs.writeFile(__dirname+"/../data/member.json", JSON.stringify(member, null, '\t'), (err, data) => {
                    if(err){
                        console.log(err);
                    }else{
                        result['code'] = 200;
                        result['msg'] = "성공";
                        res.json(result);
                    }
                });
            }
        });
    });
}