/*
    템플릿 엔진
    view를 구현하기 위한 템플릿
    여기서 view는 서버랜더링 코드를 포함한 view를 말한다

    ejs(Embedded JavaScript)
    특정 형식인 파일로부터 html패이지를 생성하는 모듈

    ejs파일 형식의 특수 코드
    <%  code  %>: 자바스크립트 코드를 입력하는 영역
    <%= 변수 %>: 데이터를 출력
    <%- 변수 %>: ejs파일 전체를 전달

    ejs 파일을 html로 변환
    ejs.render(ejs파일): 메소드의 매개변수에 전달하고자하는 데이터를 입력
*/


const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const ejs = require('ejs');

const app = express();
const port  = 3000;
const router = express.Router();

app.use(bodyParser.urlencoded({extended: false}));

router.route('/login').post((req, res) => {
    fs.readFile('./ejs1.ejs', 'utf8', (err, data) => {
        if(err){
            console.log(err);
        }else{
            res.writeHead(200, {'content-type':'text/html'});
            //클라이언트에게 ejs파일을 html로 변환하여 전송
            res.end(ejs.render(data));
        }
    })
});

app.use('/', router);

app.all('*', (req, res) => {
    res.status(404).send('<h2>페이지를 찾을 수 없습니다</h2>');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중...`);
});