/*
    redirect(): 웹 페이지의 경로를 강제로 이동
*/

const express = require('express');
const app = express();
const port = 3000;

app.use((req, res) => {
    console.log('첫번째 미들웨어 실행');
    //네이버로 이동
    res.redirect('https://naver.com');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중...`);
});