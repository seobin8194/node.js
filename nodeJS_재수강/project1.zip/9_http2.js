/* 사용자에게 보낼 html문서를 파일로 읽어 전송하기 */


const http = require('http');
const fs = require('fs');

http.createServer((req, res) => {
    fs.readFile('test.html', (err, data) => {
        if(err){
            console.log(err);
        }else{
            res.writeHead(200, {'content-type':'text/html'});
            res.end(data);
        }
    })
}).listen(3000, () => {
    console.log('서버 실행 중');
})