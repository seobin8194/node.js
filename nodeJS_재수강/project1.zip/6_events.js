/*
    이벤트 루프
    node.js는 서버가 실행되면 변수들을 초기화하고 함수를 선언하고 이벤트가 발생할때까지 기다림
    이벤트가 감지되었을때 callback함수를 호출하면서 처리
    node.js는 이런 방식으로 동작하는 프로그램 형식이 많음

    이벤트
    request: 클라이언트가 서버에 요청할때 발생하는 이벤트
    connection: 클라이언트가 접속할때 발생하는 이벤트
    close: 서버가 종료될때 발생하는 이벤트

    EventEmitter
    이벤트관련 메소드를 사용할 수 있는 객체
    emit(): 이벤트를 발생시키는 함수
    on(): 이벤트와 이벤트핸들러 연결
*/


const events = require('events');
const eventEmitter = new events.EventEmitter();

const connectHandler = function connected(){
    console.log('연결성공');
    //"data_received" 이벤트 발생
    eventEmitter.emit('data_received');
}

//이벤트와 이벤트핸들러와 연결
eventEmitter.on('connection', connectHandler);
eventEmitter.on('data_received', () => {
    console.log('데이터 수신');
});

//"connection"이벤트 발생
eventEmitter.emit('connection');

console.log('프로그램 종료');