/*
    fs 모듈

    메소드
    writeFile(): 파일을 비동기적으로 씀
    writeFileSync(): 파일을 동기적으로 씀
*/

const fs = require('fs');
const data = 'Hello Node.js';

//파일을 비동기적으로 씀
fs.writeFile('text3.txt', data, 'utf-8', (err) => {
    if(err){
        console.log('에러 발생');
    }else{
        console.log('비동기식으로 파일 저장');
    }
});

//파일을 동기적으로 씀
fs.writeFileSync('text2.txt', data, 'utf-8');
console.log('동기식으로 파일저장');