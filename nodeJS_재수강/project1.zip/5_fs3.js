const fs = require('fs');

//동기식 파일처리시 예외처리
//파일처리시 에러났을때 그대로 프로그램이 종료되는 것을 막을 수 있다
try{
    const text = fs.readFileSync('text11.txt', 'utf-8');
}catch(err){
    console.log('동기식으로 파일읽기 실패');
}

console.log('프로그램을 종료합니다');