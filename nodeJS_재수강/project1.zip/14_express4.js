/*
    request 객체
    클라이언트가 서버에게 전달하는 메시지(정보)를 담는 객체

    req.header('User-Agent'): 사용자의 os와 브라우저를 불러옴
    req.query: 클라이언트에서 get방식으로 전송한 요청 파라미터를 확인
    req.body: 클라이언트에서 post방식으로 전송한 요청 파라미터를 확인 
              (단, post방식을 통한 요청 파라미터를 확인하려면 body-parser와 같은 모듈을 사용해야함)

    write() : 클라이언트에게 전송할 데이터를 작성(버퍼에 쌓아 놓는것), end()을 실행해여 전송
*/


const express = require('express');

const app = express();
const port = 3000;

app.use((req, res) => {
    console.log('첫번째 미들웨어 실행');
    console.dir(req.header);

    //사용자의 os와 브라우저를 불러옴
    const userAgent = req.header('User-Agent');
    console.log(userAgent);

    //http://127.0.0.1:3000/?userid=apple
    //get방식으로 전송한 요청 파라미터를 확인
    const userid = req.query.userid;
    console.log(userid);

    res.writeHead(200, {'content-type':'text/html;charset=utf8'});
    //클라이언트에게 전송할 데이터를 작성
    res.write('<h2>익스프레스 서버에서 응답한 메시지입니다</h2>');
    res.write(`<p>user-Agent: ${userAgent}</p>`);
    res.write(`<p>userid: ${userid}</p>`);
    //전송
    res.end();
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중...`);
});