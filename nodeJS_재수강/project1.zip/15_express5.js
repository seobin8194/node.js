/*
    request객체에 담긴 post 데이터 받기

    app.use(bodyParser.urlencoded({extended: false}))
    - body-parser를 사용하면 자동으로 req에 body속성이 추가되고 저장됨
    - 인코딩이 기본적으로 utf-8 임
    - urlencoded({extended: false}): 중첩된 객체표현을 허용할지 여부를 체크    
      * url 파싱
      - qs
      - query-string
      두 파싱방식은 겹치는 메소드가 존재하여 두 파싱방법을 같이 사용하면 충돌이 발생한다
      따라서 두 파싱방식을 같이 사용하지 않고 query-string방식만을 이용하기 위해 {extended: false}작성

    req.body: 클라이언트에서 post방식으로 전송한 요청 파라미터를 확인
*/


const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

//기존에 존재하던 모듈인 bodyParser를 미들웨어로 등록
app.use(bodyParser.urlencoded({extended: false}));
app.use((req, res) => {
    //클라이언트에서 post방식으로 전송한 요청 파라미터를 확인
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    console.log(`userid:${userid}, userpw:${userpw}`);

    res.writeHead(200, {'content-type':'text/html;charset=utf-8'});
    res.write('<h2>익스프레스 서버에서 응답한 메시지입니다</h2>');
    res.write(`<p>아이디: ${userid}</p>`);
    res.write(`<p>비밀번호: ${userpw}</p>`);
    res.end()
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중...`);
});