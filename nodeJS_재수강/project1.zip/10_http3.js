/* 
    사용자에게 html문서가 아닌 다른 형태의 데이터 전송하기

    MIME 형식
    header에 보낼 데이터에 해당하는 MIME형식을 작성하여 브라우저에게 데이터 형태를 알린다
    text/plain: 일반적인 텍스트 파일
    text/html: html 형삭 파일
    text/css: css 형식 파일
    image/jpeg: jpeg 이미지 파일
    imag/png: png 이미지 파일
    video/mpeg: mpeg 동영상 파일
    audio/mp3: mp3 음악 파일

    youtube노래 m3로 변환하는 사이트
    https://ytmp3.cc/youtube-to-mp3/
*/


const http = require('http');
const fs = require('fs');

http.createServer((req,res) => {
    fs.readFile('snow1.png', (err, data) => {
        if(err){
            console.log(err);
        }else{
            //이미지를 전달할거라고 브라우저에게 알리기 위한 header
            res.writeHead(200, {'content-type':'image/png'});
            //이미지 전달
            res.end(data);
        }
    });

}).listen(3000, () => {
    console.log('이미지 서버 실행 중');
});

http.createServer((req,res) => {
    fs.readFile('sound.mp3', (err, data) => {
        if(err){
            console.log(err);
        }else{
            //음원을 전달할거라고 브라우저에게 알리기 위한 header
            res.writeHead(200, {'content-type':'audio/mp3'});
            //음원 전달
            res.end(data);
        }
    });

// 사용자가 요청하면 lan카드까지만 연결하고 port번호를 통해 어떤 프로그램과 연결할지 결정
// 따라서 포트번호에 따라 다른 서비스를 제공할 수 있다
}).listen(4000, () => {
    console.log('mp3 서버 실행 중');
});