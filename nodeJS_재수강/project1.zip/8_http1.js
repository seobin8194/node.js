/*
    http 모듈
    node.js에서 가장 기본적이고 중요한 서버 모듈
    http 웹 서버를 생성하는 것과 관련된 모든 기능을 담당

    createServer(callback함수): 웹 서버 객체 생성
        callback함수 -> 서버 생성시 실행되는 함수

    내장객체
    server 객체: createServer() 메소드를 사용하여 생성
    request 객체: 클라이언트가 서버에게 전달하는 메시지(정보)를 담는 객체
    response 객체: 서버에서 클라이언트로 응답 메시지를 전송시켜주는 객체

    writeHead(): 응답 header를 구성하는 함수
                 사용자에게 전달할 데이터 형태를 브라우저에게 알려줌으로써 브라우저가 해당 데이터처리할 준비를 할 수 있다
    end(): 응답 body를 작성하는 함수
    listen(): 서버를 실행하고 클라이언트를 기다림
*/


const http = require('http');

//서버생성
http.createServer((req, res) => {
    //응답헤더 작성
    res.writeHead(200, {'content-type':'text/html'});
    //응답바디 작성하여 전송
    res.end('<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>http 모듈 테스트</title></head><body><h2>http 모듈 태스트</h2><p>처음으로 실행하는 node.js http 서버</p></body></html>');

//클라이언트의 접속 대기
}).listen(3000, () => {
    console.log('서버 실행 중');
});