/*
    express 모듈의 미들웨어
    express에 여러 기능을 추가할 수 있음을 의미

    use(): 미들웨어 등록
           원래 기능뿐만 아니라 내가 직접 작성하여 기능을 추가할 수도 있다
*/


const express = require('express');

const app = express();
const port = 3000;

//내가 직접 작성한 기능을 미들웨어로 등록
app.use((req, res) => {
    res.writeHead('200', {'content-type':'text/html;charset=utf8'});
    res.end('<h2>익스프레스 서버에서 응답한 메시지입니다</h2>');
});

app.listen(port, () => {
    console.log(`${port}로 서버 실행 중...`);
});
