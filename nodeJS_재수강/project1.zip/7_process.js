/*
    시스템 이벤트
    exit: 프로그램이 종료되거나 종료되는 시점을 알 수 있음

    process 객체
    노드에서 항상 사용할 수 있는 객체(require하지 않아도 됨)
    exit는 process객체에 포함
*/


process.on('exit', () => {
    console.log('exit 이벤트 발생');
});

setTimeout(() => {
    console.log('프로그램을 종료합니다');
    //프로그램 종료
    process.exit
}, 3000);