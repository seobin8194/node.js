/*
    Rest
    자원을 이름으로 구분하여 해당 자원의 상태를 주고받는것을 의미

    Router
    사용자의 다양한 요청이 들어왔을때 use()메소드로 설정한 미들웨어가 항상 호출되는 불편한 점 개선
    요청 페이지와 방식에 따라 다른 작업을 수행하고 싶을때 사용

    const 라우터객체 = express.Router();
    라우터객체.route('요청 path').get/post(실행할 함수)
    app.use('/', 라우터객체);
 */
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port  = 3000;
const router = express.Router();

app.use(bodyParser.urlencoded({extended: false}));

router.route('/member/login').post((req, res) => {
    console.log('/member/login 호출');
});

router.route('/member/regist').post((req, res) => {
    console.log('/member/regist 호출');
});

router.route('/member/about').get((req, res) => {
    console.log('/member/about 호출');
})

app.use('/', router);

//에러 페이지
//잘못된 url로 접근시 보여줄 내용을 지정할 수 있다
//Router를 적용한 후에 사용해야한다
app.all('*', (req, res) => {
    res.status(404).send('<h2>페이지를 찾을 수 없습니다</h2>');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중...`);
});