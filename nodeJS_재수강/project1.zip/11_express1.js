/*
    express 모듈
    http모듈만 사용해서 웹 서버를 구성하면 직접 많은 기능을 개발해야한다
    간단한 코드로 웹 서버의 기능을 대부분 구현할 수 있음 
    미들웨어와 라우터를 이용하여 편리하게 웹 서버를 구성할 수 있다

    get(): get방식으로 요청한 사용자의 정보를 전달받음
    send(): body 전송
*/

const express = require('express');

const app = express();
const port = 3000;

//'/'요청을 get방식으로 받음
app.get('/', (req, res) => {
    //헤더 작성하지 않을시 default는 html문서
    
    res.send('익스프레스 서버 테스트')
});

app.listen(port, () => {
    console.log(`${port}포트로 실행 중..`);
});