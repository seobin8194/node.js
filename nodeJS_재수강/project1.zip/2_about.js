//http모듈을 가져다쓰겠다
const http = require('http');

const hostname = '127.0.0.1';
const port = 3000;

//createServer(): 웹 서버 기능 생성
//(req, res): req(접속자 정보) res(전달할 정보)
const server = http.createServer((req, res) => {  
  res.statusCode = 200;
  //사용자에게 전달할 데이터 형태를 브라우저에게 알려줌으로써 브라우저가 해당 데이터처리할 준비를 할 수 있다
  res.setHeader('Content-Type', 'text/plain');
  //사용자에게 데이터 전달
  res.end('Hello World');
});

//서버가 해당 포트번호로 서버를 열어 사용자를 기다림
server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});