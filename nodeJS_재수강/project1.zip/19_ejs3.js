/*
    ejs파일로 ejs파일 전달
    ejs.render(ejs파일, {key : ejs.render(ejs파일)})

    ejs파일에서는 <%- %> 안에서 받음
*/


const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const ejs = require('ejs');

const app = express();
const port  = 3000;
const router = express.Router();

app.use(bodyParser.urlencoded({extended: false}));

const header = fs.readFileSync('./header.ejs', 'utf-8');
const body = fs.readFileSync('./body.ejs', 'utf-8');

router.route('/about').post((req, res) => {
    // ejs파일로 ejs파일을 포함한 데이터 전달
    const html = ejs.render(header, {title:'매개변수로 전달된 제목', content:ejs.render(body, {message:'매개변수로 전달된 메시지'})});
    res.end(html);   
});

app.use('/', router);

app.all('*', (req, res) => {
    res.status(404).send('<h2>페이지를 찾을 수 없습니다</h2>');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중...`);
});