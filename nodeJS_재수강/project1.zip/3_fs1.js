/*
    fs 모듈
    파일처리와 관련된 모듈
    Node.js에서 가장 중요하고 기초가 되는 모듈

    메소드
    readFile(): 파일을 비동기적으로 읽음
    readFileSync(): 파일을 동기적으로 읽음
    * 동기와 비동기
      자원을 사용하는 (파일, 이미지관련) 연산, 반복문과 같이 시간이 걸리는 작업을 수행할때 동기와 비동기를 구분할 수 있다
      동기식: 프로그램이 동작하는 상태에서 완전히 해당 내용을 끝내고 다음으로 넘기는 방식
      비동기식: 동작이 끝나지 않은 상태에서도 제아권을 넘긴 후 프로그램을 계속 진행하는 방식
*/


const fs = require('fs');

//비동기식으로 파일읽기
//제어권을 넘긴 후 다시 돌아 올때 실행되는 callback함수
//err: 파일읽지 못했을때 첫번째 파라미터에 err객체가 들어온다
//data: 파일을 읽었을때 두번째 파라미터에 읽은 데이터가 들어온다
fs.readFile('text1.txt', 'utf-8', (err, data) => {
    if(err){
        console.log(err);
    }else{
        console.log(`비동기식으로 읽음: ${data}`)
    }
});

//동기식으로 파일 읽기
const text = fs.readFileSync('text1.txt', 'utf-8');
console.log(`동기식으로 읽음 : ${text}`);
