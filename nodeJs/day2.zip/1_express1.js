const express = require('express');
//post데이터를 전달받기 위한 모듈
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

//익스프레스에 미들웨어 기능을 추가 -> bodyParser의 urlencoded()기능을 추가
//extended를 false로 지정하면 application/x-www-form-urlencoded(일반적인 폼태그 전달방식) 파싱
app.use(bodyParser.urlencoded({extended: false}));
app.use((req, res) => {
    //post로 전달한 데이터 받기
    const paramId = req.body.userid;
    const paramPw = req.body.userpw;
    console.log(`paramId : ${paramId}, paramPw : ${paramPw}`);

    res.writeHead(200, {'content-type':'text/html;charset=utf-8'});
    res.write('<h2>익스프레스에소 응답한 메시지입니다</h2>');
    res.write(`<p>아이디 : ${paramId}</p>`);
    res.write(`<p>비밀번호 : ${paramPw}</p>`);
    res.end();
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중,,`);
});