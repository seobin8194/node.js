/*
    템플릿 엔진
    php와 같은 서버개발 코드가 섞인 페이지를 응답할때
    EJS(Embeded Javascript)모듈
    EJS 모듈은 템플릿 모듈입니다. 
    템플릿 엔진 모듈은 특정한 형식인 파일로부터 html 페이지를 생성하는 모듈이다. 
    즉 html형식에 서버사이드 코드를 삽입하고 이 파일이 컴파일을 거치면서 html화된다

    EJS파일 형식의 특수코드
    <% ~~~~~ code ~~~~~ %> : 자바스크립트 코드를 입력하는 영역
    <&= 변수 또는 값 %> : 데이터를 출력
    <%- 변수 또는 객체 %> : ejs파일 전체를 전달

    ejs 데이터 전달
    render() : 메소드의 매개변수에 전달하고자하는 데이터를 입력하여 전달
    ejs.render(data);(data는 서버코드가 섞인 html파일)
*/

const express = require('express');
const fs = require('fs');
//npm i ejs
const ejs = require('ejs');

const app = express();
const port = 3000;

const router = express.Router();

router.route('/ejs/test').post((req, res) => {
    fs.readFile('ejs1.ejs', 'utf-8', (err, data) => {
        if(!err){
            res.writeHead(200, {'content-type':'text/html'});
            //특정 형식 파일을 html파일로 변환하여 전달
            res.end(ejs.render(data));
        }else{
            console.log(err);
        }
    })
});

app.use('/', router);

app.all('*', (res, req) => {
    res.statusCode(404).send('<h3>페이지를 찾을 수 없습니다</h3>');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행 중,,`);
});