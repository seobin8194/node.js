const express = require('express');
const bodyParser = require('body-parser');
//serve-static
//npm i serve-static
//http://localhost:3000/public/apple.jpg 실제 저장경로
//http://localhost:3000/apple.jpg static을 통해서 요청 경로를 변경할 수 있다
const static = require('serve-static');
const path = require('path');
//morgan
//npm i morgan
//post호출했다 get호출했다 로그 찍음
const logger = require('morgan');
//npm i multer
const multer = require('multer');

const app = express();
const router = express.Router();
const port = 3000;

app.use(bodyParser.urlencoded({extended:false}));
// /public경로를 루트경로로 부를 수 있다
//app.use('/', static(path.join(__dirname, 'public')));
//경로를 잡아줬기때문에 라우터나 따로 요청받는 코드없이 /public/write.html요청을 받을 수 있다
app.use('/public', static(path.join(__dirname, 'public')));
app.use('/uploads', static(path.join(__dirname, 'uploads')));
//옵션: dev, short, common, bombined
app.use(logger('dev'));

//multer의 diskStorage설정 객체
const storage = multer.diskStorage({
    //req된 파일을 uploads폴더에 저장할것이다
    //파일요청이 들어오면 callback()을 실행하여 함수를 호출한(자기 함수)에게 에러(null) 혹은 저장할 위치를 반환
    destination: (req, file, callback) => {
        callback(null, 'uploads');
    },
    filename: (req, file, callback) => {
        //extname(): 확장명 떼주는 메소드
        const extension = path.extname(file.originalname);
        //파일명에서 확장명 떼고 이름만
        const basename = path.basename(file.originalname, extension);
        //자기자신에게 수정한 파일명을 반환
        callback(null, basename + "_" + Date.now() + extension);
    }
});

//multer 생성자에 diskStorage 설정과 파일 크기를 설정
const upload = multer({
    storage: storage, //disStorage 설정
    limit: {
        files: 5,//파일개수 제한
        fileSize: 1024*1024*100 //파일용량제한
    }
});

//post방식을 통해 photo란 이름으로 파일배열 받을 준비
router.route('/write').post(upload.array('photo', 1), (req, res) => {
    console.log('/write');
    try{
        const title = req.body.title;
        const content = req.body.content;
        //넘어오는 파일배열을 받는다
        const files = req.files;
        console.dir(files[0]);
        const originalname = files[0].originalname;
        const filename = files[0].filename;
        const mimetype = files[0].mimetype;
        const size = files[0].size;
        console.log(`파일정보 : 원본파일명: ${originalname}, 파일이름: ${filename}, mimetype: ${mimetype}, 파일크기: ${size}`);

        res.writeHead('200', {'content-type':'text/html;charset=utf8'});
        res.write('<h2>파일 업로드 성공</h2>');
        res.write('<hr>');
        res.write(`<p>제목: ${title}</p>`)
        res.write(`<p>내용: ${content}</p>`)
        res.write(`<p>원본파일명: ${originalname}</p>`)
        res.write(`<p>파일명: ${filename}</p>`)
        res.write(`<p>mimetype: ${mimetype}</p>`)
        res.write(`<p>파일크기: ${size}</p>`)
        res.write(`<p><img src='/uploads/${filename}' width='200'></p>`);
    }catch(e){
        console.log(e);
    }
});

app.use("/", router);
app.listen(port, () => {
    console.log('서버실행');
});