const express = require('express');
const fs = require('fs');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth:{
        user: 'wjdtjqls8194@gmail.com',
        pass: 'hoho1010!@'
    }, 
    host: 'smtp.mail.com',
    port: '465'
});

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({extended: false}));

const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, 'uploads');
    },
    filename: (req, file, callback) => {
        const extension = path.extname(file.originalname);
        const basename = path.basename(file.originalname, extension);
        callback(null, basename + "_" + Date.now() + extension);
    }
});
const upload = multer({
    storage:storage,
    limits:{
        files:5,
        fileSize:1024*1024*100
    }
});

const router = express.Router();

router.route('/mailForm').get((req, res) => {
    fs.readFile('mailForm.ejs', 'utf8', (err, data) => {
        if(!err){
            res.writeHead(200, {'content-type':'text/html'});
            res.end(ejs.render(data));
        }else{
            console.log(err);
        }
    });
});

router.route('/sendMail').post(upload.array('photo', 1), (req, res) => {
    const from = req.body.from;
    const fromEmail = req.body.fromEmail
    const to = req.body.to;
    const toEmail = req.body.toEmail;
    const title = req.body.title;
    const content = req.body.content;
    const files = req.files;

    fs.readFile('./uploads/' + files[0].filename, (err, data) => {
        if(!err){
            const mailOptions = {
                from: from + "<" + fromEmail + ">",
                to: to + "<" + toEmail + ">",
                subject: title,
                text: content,
                attachments: [{'filename':files[0].filename, 'content':data}]
            };
            
            transporter.sendMail(mailOptions, (err, info) => {
                transporter.close();
                if(err){
                    console.log(err);
                }else{
                    console.log(info);
                }
            });

        }else{
            console.log(err);
        }
    }); 
});

app.use('/', router);
app.all('*', (req, res) => {
    res.status(404).send('<h2>페이지가 없습니다</h2>');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행중,,`);
});