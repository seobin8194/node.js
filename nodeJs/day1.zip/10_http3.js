const http = require('http');
const fs = require('fs');

//포트별로 다르게 동작할 수 있다
//예를들면 react와 node.js가 서로 다른 포트번호를 사용하여 협업을 하거나 
//채팅서버와 페이지 서버 각각 다른 포트번호를 이용하여 돌릴수 있다

http.createServer((req, res) => {
    //사용자에게 이미지파일을 화면에 보여준디
    fs.readFile('node.png', (err, data) => {
        if(err){
            console.log(err);
        }else{
            res.writeHead(200, {'content-type':'image/png'});
            res.end(data);
        }
    });
}).listen(3000, () => {
    console.log('이미지 서버 실행 중');
});

http.createServer((req, res) => {
    //사용자에게 사운드파일을 화면에 보여준디
    fs.readFile('sunny.mp3', (err, data) => {
        if(err){
            console.log(err);
        }else{
            res.writeHead(200, {'content-type':'audio/mp3'});
            res.end(data);
        }
    });
}).listen(3001, () => {
    console.log('사운드 서버 실행 중');
});