//require(): 다른 모듈을 여기에 포함시킴 (import)
const http = require('http');

const hostname = '127.0.0.1';
const port = 3000;

//createServer: 웹 서버 띄움. 사용자 요청이 들어왔을때의 처리를 어떻게 할지 작성
//req: 사용자가 요청한 정보를 담은 객체
//res: 서버가 사용자에게 전달할 정보를 담은 객체
const server = http.createServer((req, res) => {
  //statusCode : 브라우저에게 상태코드전달 200:정상 404:페이지 없음
  res.statusCode = 200;
  //서버가 사용자에게 데이터 전달시 헤더와 바디를 전달할 수 있다
  //헤더 : 어떤 형태(html, xml, json, 이미지, 텍스트)페이지를 전달할지에 대한 정보를 담는다. 
  //       브라우저는 이 정보를 받아 각 형태에 따른 해석기를 준비할 수 있다
  //바디 : 실제 화면에 보여줄것을 담는다
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello World');
});

//listen : 해당 ip와 포트번호로 사용자가 들어 오길 대기
server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});