const express = require('express');
//익스프레스 객체 생성
const app = express();
const port = 3000;

//localhost:3000으로 get방식으로 접속하면
app.get('/', (req, res) => {
    res.send('익스프레스 서버 테스트');
});

app.listen(port, () => {
    console.log(`${port}포트로 서버 실행중..`);
});
