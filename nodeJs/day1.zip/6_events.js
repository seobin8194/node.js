/*
    이벤트 루프(Event Loop)
    서버측 이벤트 : 사용자가 내 사이트에 들어옴/나감
    node.js는 서버가 가동되면 변수들을 초기화하고 함수를 선언하고 이벤트가 발생할때까지 기다린다
    이벤트가 감지되었을때 콜백함수를 호출된다

    events
    이벤트 위주의 프로그램을 작성할때 사용하는 모듈입니다
    메소드
    on() : 지정한 이벤트의 리스너를 추가
    once() : 지정한 이벤트의 리스너를 추가하지만 한번 실행 이후 자동 제거
    removelistener() : 지정한 이벤트에 대한 리스너를 제거
    emit() : 지정한 이벤트를 발생
*/

const events = require('events');

//이벤트관련 메소드를 사용할 수 있는 EventEmitter객체를 만든다
const eventEmitter = new events.EventEmitter();

//connectHandler 핸들러
const connectHandler = function connected() { //2. connectHandler 실행
    console.log('연결성공');
    eventEmitter.emit('data_received'); //3. data_received 발생
}

//connection 이벤트와 connectHandler 핸들러와 연결
eventEmitter.on('connection', connectHandler);

//data_receive 이벤트와 익명함수와 연결
eventEmitter.on('data_received', () => { //4. 익명함수 실행
    console.log('데이터 수신');
});

eventEmitter.emit('connection'); //1. connection 이벤트 발생
console.log('프로그램 종료'); 