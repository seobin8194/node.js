/*
    http 모듈
    node.js에서 가장 기본적이고 중요한 서버 모듈입니다
    http 웹 서버를 생성하는 것과 관련된 모든 기능을 담당
    실제로는 많이 사용하지 않음
    1. server 객체
    http 모둘의 createserver() 메소드를 사용해서 server객체를 생성
    - 메소드
    listen() : 서버를 실행하고 클라이언트를 기다립니다
    close() : 서버를 종료
    - 이벤트
    request : 클라이언트가 서버에 요청할때 발생
    connection : 클라이언트가 접속할때 발생
    close : 서버가 종료될때 발생

    2. request 객체
    클라이언트가 서버에게 전달하는 메시지(정보)를 담는 객체
    - 속성
    method : 클라이언트 요청방식을 나타냅니다 (post, get)
    url : 클라리언트가 요청한 url을 나타냅니다
    http://www.ryuzy.com/blog/index?userid=apple&username=김사과
    <---------------------------------------------------------->
                                uri
    <------------------------------>
                url
    <------------------><---------->          
        domain         pathname

    3. respond 객체
    서버에서 클라이언트로 응답 메시지를 전송시켜주는 객체
    - 메소드
    writeHead() : 응답헤더를 작성
    end() : 응답 본문을 작성
    * MIME 형식
    text/plain : 일반적인 text 파일
    text/html : html 형식 파일
    text/css : css 형식 파일
    text/xml : xml 형식 파일
    image/jpeg : jpeg 이미지 파일
    video/mpeg : mpeg 동영상 파일
    audio/mp3 : mp3 음악 파일

    http 모듈 확인 방법
    http://localhost:3000
    http://127.0.0.1:3000
    http://192.168.10.103:3000(본인 컴퓨터 ip)
*/

const http = require('http');

//사용자가 접속하면 request객체와 respond 객체가 자동 생성
http.createServer((req, res) => {
    //사용자가 들어오면
    res.writeHead(200,{'content-type':'text/html'});
    res.end('<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>http 모듈 테스트</title></head><body style="background-color: aquamarine;"><h2>http 모듈 테스트</h2><p>차음으로 실행하는 node.js http 서버</p></body></html>');
}).listen(3000, () => {
    console.log('서버 실행 중');
});