/*
    시스템 이벤트
    process 객체는 노드에서 항상 사용할 수 있는 객체입니다
    process 객체 내 on()과 emit() 메소드는 객체를 생성하거나 모듈을 가져오지 않아도 바로 사용할 수 있다

    exit는 시스템 종료할때를 의미하거나 시스템을 종료하는 키워드
    on() 메소드를 호출하면서 이벤트이름을 exit로 지정하면 내부적으로 프로세스가 끝날때를 알 수 있다
*/

process.on('exit', () => {
    console.log('exit 이벤트 발생');
});

setTimeout(() => {
    console.log('3초 후 시스템 종료');
    process.exit;
}, 3000);