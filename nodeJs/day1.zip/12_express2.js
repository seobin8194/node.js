const express = require('express');
const app = express();
const port = 3000;

//미들웨어 등록
//사용자가 들어오면 어떤 처리를 하겠다라는 기능을 등록
//모듈이나 원래 있는 기능도 추가 가능
app.use((req, res) => {
    res.writeHead('200', {'content-type':'text/html;charset=utf-8'});
    res.end('<h2>익스프레스 서버에서 응답한 메시지</h2>');
});

app.listen(port, () => {
    console.log('서버 실행 중');
});