const fs = require('fs');

/*
    예외처리란 프로그램이 동작하는 동안 예외가 발생하여 프로그램이 종료되는 것을 방지하기위함

    프로그램이 실행되고 있는 런타임시에 에러가 발생할 경우 처리할 수 있는 프로그램 구간을 의미
    try{
        예외상황이 발생할 수 있는 문장
    }catch(e){
        예외상황이 발생했을 경우 처리할 문당(e는 Exception 객체)
    }finally{
        예외상황이 발생하거나 발생하지 않아도 무조건 실행될 문장(생략가능)
    }
*/

//비동기 처리는 예외처리를 할 필요없다
//이미 에러를 받아서 처리하기 때문
fs.readFile('text11.txt', 'utf-8', (err, data) => {
    if(err){
        console.log('에러발생 / 비동기');
    }else{
        console.log(data);
    }
});

try{
    const text = fs.readFileSync('text11.txt','utf-8');
    console.log(`동기식으로 읽음 : ${text}`);
}catch(e){
    console.log('에러발생 / 동기');
}

console.log('프로그램 종료');