//passport 회원가입
//로컬 회원가입

//passport-local을 셋팅해주기 위한 객체
//npm i passport-local
const LocalStrategy = require('passport-local').Strategy;

module.exports = new LocalStrategy({
    //아이디 필드명 지정
    usernameField: 'userid',
    //비밀번호 필드명 지정
    passwordField: 'userpw',
    //패스워드에 대한 응답
    passReqToCallback: true

}, (req, userid, userpw, done) => {
    const name = req.body.name;
    const age = req.body.age;
    console.log(`passport의 local-signup호출 : userid:${userid}, userpw:${userpw}, name:${name}, age:${age}`);

    //nextTick(): 실행문에서 데이터가 blocking되지 않도록 사용
    //async방식으로 변경 -> 여러 사용자들의 회원가입처리를 병행하기 위함
    process.nextTick(() => {
        let database = req.app.get('database');
        database.MemberModel.findOne({userid:userid}, (err, user) => {
            if(err){return done(err)}
            if(user) {
                console.log('이미 가입된 계정입니다');
                return done(null, false);
            }else{
                let user = new database.MemberModel({userid:userid, userpw:userpw, name:name, age:age});
                user.save((err) => {
                    if(err) {throw err;}
                    console.log('가입완료');
                    return done(null, user);
                });
            }    
        })
    })
});


