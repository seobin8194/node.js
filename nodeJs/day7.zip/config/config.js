//유지보수를 위해 변경가능성이 있는 설정들을 모아놓은 파일
module.exports = {
    //사이트 운영할때 AWS에 올리고 80번 포트로 변경하는 등 포트번호는 변경가능성이 있다
    server_port: 3000,
    //DB서버를 따로 만들어 운영하는 경우도 있다
    //사이트에 부하가 가면 DB도 느려질 수 있으니까
    db_url: 'mongodb://localhost:27017/frontenddb',
    db_schemas: [{file:'./member_schema', collection: 'member2', schemaName:'MemberSchema', modelName:'MemberModel'}],
    facebook: {
        //페이스북 개발자 센터에서 가져온다
        clientID: '1328512427518644',
        clientSecret: '98d9c806f834f9c36a1a53b751da6e7c',
        //인증받고 어디로 갈껀지
        //풀 경로를 작성해야한다
        //인증받기 위해 facebook사이트에 갔다가 다시 돌아오는거기 때문에 상대경로로 작성하면 facebook 사이트에서의 상대경로이기 때문에 못 돌아온다
        callbackURL: 'http://localhost:3000/auth/facebook/callback'
    }
}