const express = require('express');
const bodyParser = require('body-parser');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const expressSession = require('express-session');
//npm i passport
const passport = require('passport');
const static = require('serve-static');
const path = require('path');
//npm i express-error-handler
const expressErrorHandler = require('express-error-handler');

const app = express();
const router = express.Router();

app.use(cookieParser());
app.use(expressSession({
    secret: '!@#$%^&*()',
    resave: false,
    saveUninitialized: true,
    cookie: {maxAge: 60*60*1000}
}));
app.use(logger('dev'));
//passport 초기화
app.use(passport.initialize());
//passport 세션을 사용하려면 그 전에 express 세션을 사용하는 코드가 먼저 나와야 한다
//passport 세션은 express 세션을 빌려다 사용하기 때문이다
app.use(passport.session());
app.use(bodyParser.urlencoded({extended:false}));
// /public == dirname join as public
app.use('/public', static(path.join(__dirname, "public")));
app.use('/', router);

const errorHandler = expressErrorHandler({
    //static: 메모리에 미리 올리겠다
    static: {
        //404에러가 뜨면 보여줄 페이지를 지정한다
        '404': './public/404.html'
    }
});
//404가 발생하면 expressErrorHandler로 처리하겠다
app.use(expressErrorHandler.httpError(404));
app.use(errorHandler);

//set(): express 기능 셋팅
//views란 views폴더 경로라고 셋팅
app.set('views', __dirname + '/views');
//view engine으로 ejs엔진을 사용하겠다고 설정
app.set('view engine', 'ejs');

const config = require('./config/config');
const database = require('./database/database');
const configPassport = require('./config/passport');
//./config/passport모듈 실행
configPassport(app, passport);

const userPassport = require('./routes/route_member');
userPassport(router, passport);

app.listen(config.server_port, () => {
    console.log(`${config.server_port}포트로 서버 실행 중,,,`);
    database.init(app, config);
});