const express = require('express');
//npm i cookie-parser
const cookirParser = require('cookie-parser');

const app = express();
const port = 3000;

//cookie-parser객체 생성하여 express에 미들웨어로 등록
app.use(cookieParser());

app.get('/setCookie', (req, res) => {
    console.log('setCookie 호출');
    //쿠키 생성
    res.cookie('member', {
        id: 'apple',
        name: '김사과',
        gender: 'female'

    }, {
        maxAge: 1000*60*60
    });
    res.redirect('/showCookie');
});

app.get('/showCookie', (req, res) => {
    console.log('showCookie 호출');
    //쿠키 조회해서 사용자에게 보냄
    res.send(req.cookies);
    res.end();
});

app.listen(port, () => {
    console.log('서버 실행중');
});