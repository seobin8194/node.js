const express = require('express');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({extended: false}))
//암호화된 쿠키를 사용할때의 cookie-parser 객체 생성
app.use(cookieParser('!@#$%^&*()'));

app.get('/login', (req, res) => {
    fs.readFile('login.html', 'utf8', (err, data) => {
        if(!err){
            res.writeHead(200, {'content-type':'text/html'});
            res.end(data);
        }else{
            console.log(err);
        }
    });
});

app.post('/loginOk', (req, res) => {
    const userid = req.body.userid;
    const userpw = req.body.userpw;
    console.log(userid);
    console.log(userpw);

    if(userid == 'admin' && userpw == '1234'){
        const expireDay = new Date(Date.now() + (1000*60*60*24));
        //로그인 성공시 userid쿠키 생성
        res.cookie('userid', userid, {expires: expireDay, signed: true});
        res.redirect('/welcome');
    }else{
        res.redirect('/fail');
    }
});

app.get('/welcome', (req, res) => {
    //userid 쿠키 조회
    const cookieUserid = req.signedCookies.userid;
    console.log(cookieUserid);

    if(cookieUserid){
        fs.readFile('welcome.html', 'utf8', (err, data) => {
            res.writeHead(200, {'content-type':'text/html'});
            res.end(data)
        })
    }else{
        res.redirect('/login')
    }
});

app.get('/fail', (req, res) => {
    fs.readFile('fail.html', 'utf8', (err, data) => {
        if(!err){
            res.writeHead(200, {'content-type':'text/html'});
            res.end(data);
        }else{
            console.log(err);
        }
    });
});

app.get('/logout', (req, res) => {
    //userid 쿠키 삭제
    res.clearCookie("userid");
    res.redirect('/login');
});

app.listen(port, () => {
    console.log('서버 실행')
});